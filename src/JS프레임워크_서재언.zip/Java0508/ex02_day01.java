/*
 	Date : 2020.05.08
  	Author : SEO
  	Description : Java 기본 설정
  	version : 1.0   
  
 
 */



	package Java0508;

	public class ex02_day01 {
		public static void main(String[] args) {
			
			String name; 
			name = "서재언";
			String birth;
			birth = "92.10.31";
			int age=10;
			age = 29;
			String adr;
			adr = "용현동 매소홀로 59번지"; 
			String phone;
			phone = "010 2991 4194";
			String email;
			email = "wodjs4194@naver.com";
			String hobby;
			hobby = "자전거";
			String speciality;
			speciality = "정보통신";
			char blood;
			blood = 'O';
			
			
			String member1;
			member1 = "이재홍";
			String member2;
			member2 = "유현서";
			String member3;
			member3 = "오형록";
			String member4;
			member4 = "서민재";
			
			System.out.println("제 이름은 " + name + "입니다.");
			System.out.println("제 생일은" + birth + "입니다.");
			
			
			
			
			System.out.println("제 나이는" + age + "입니다.");
			System.out.println("제 주소는" + adr + "입니다." );
			System.out.println("제 핸드폰 번호는" + phone + "입니다.");
			System.out.println("제 이메일은" + email + "입니다.");
			System.out.println("제 취미는" + hobby + "입니다.");
			System.out.println("제 전공은" + speciality + "입니다.");
			System.out.println("우리 팀원1은" + member1 + "입니다.");
			System.out.println("우리 팀원2는" + member2 + "입니다." );
			System.out.println("우리 팀원3은" + member3 + "입니다.");
			System.out.println("우리 팀원4는" + member4 + "입니다.");
			
			
			
		}
	
  
}
