/*
 	Date : 2020.05.08
  	Author : SEO
  	Description : Java 기본 설정
  	version : 1.0 
  */



package Java0508;

public class ex02_string {

	public static void main(String[] agrs) {
		String str1 = "자바공부는";
		String str2 = "재미있어";
		String str3 = "너무어려워";
		
		String result;       // 변수선언
		result = str1 + str2; // 변수 초기화
		//System.out.println(result);
		
		result = str1 + str3;
		//System.out.println(rsult);
		
		result = str1 + 8.0;
		//System.out.println(result);
		
		System.out.println(str1 + str2);
		System.out.println(str1 + "너무" + str2);
		
		System.out.println
		
	}
}
