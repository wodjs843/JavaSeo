package Java0508;

public class ex02_변수 {

}
