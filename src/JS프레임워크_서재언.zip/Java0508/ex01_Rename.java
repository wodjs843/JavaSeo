/*
  	Date : 2020.05.08
  	Author : SEO
  	Description : Java 기본 설정
  	version : 1.0
*/
package Java0508;

public class ex01_Rename {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 주석달기
		// 1. 한줄 주석 처리
		/* 2.범위 주석처리*/
		// ; => 문장의 마침표 역할
		System.out.println("tresh paper");
		System.out.println("tresh paper");
		
		//sysout 입력 후 [ctr1] + [space bar]
		System.out.println();
		System.out.println("sysout 입력 후 [ctr1] + [space bar]");
		
		//실행   =>  [ctr]	+ [F11]
		
		//저장 (save) => [ctr] + [s]
		// 모두저장 (save a11) => [ctr1] + [shift] + [a]
		
		// 크기조정
		// 컨트롤 - = 작게   컨트롤  + 는 크게

	}

}
