package Java0508;

public class ex01_2 {

}
